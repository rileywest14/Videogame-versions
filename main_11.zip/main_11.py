import pygame
import os
import sys
import datetime

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Set up the game window size (500x500) and title "First Game"
win = pygame.display.set_mode((500, 500))
pygame.display.set_caption("First Game")

# Initialize the mixer for sounds
pygame.mixer.init()

# Load the background music file (make sure it's in the same directory or provide a full path)
pygame.mixer.music.load('C:/Users/au631/OneDrive - KingsWay School/DGT/Website Asessment 2024/backround_music_no_copyright.mp3')

# Play the background music indefinitely (loops=-1 for infinite looping)
pygame.mixer.music.play(loops=-1)
 
# Set the volume (optional, 0.0 is mute and 1.0 is full volume)
pygame.mixer.music.set_volume(0.5)

# Set up font for in-game text (scoreboard and health displays)
font = pygame.font.SysFont(None, 55)

# Import date and time for displaying current date and time information
import datetime
current_time = datetime.datetime.now()
print("Current time:", current_time)
print("Year:", current_time.year)
print("Month:", current_time.month)
print("Day:", current_time.day)


# Define player coordinates, size, and movement speed (vel)
x = 50
y = 50
width = 40
height = 60
vel = 5

kills = 0 #For scoreboard to show how many enemys killed
isJump = False  # Control jump state
jumpCount = 10  # Jump count used to create smooth jump
run = True  # Control main game loop



# Gravity-related variables for player movement and jump behavior
gravity = 1
fall_speed = 0
is_jumping = False  # Control whether player is in the air
jump_power = 20  # Jump force
ground_y = 500 - height  # Define ground level based on window size and player height

# Enemy settings (size, movement speed, health)
enemy_x = 400
enemy_y = 400
enemy_width = 40
enemy_height = 60
enemy_vel = 2  # Speed of enemy movement
enemy_health = 100  # Initial enemy health
def game_loop():
    run = True
    while run:
# Define health system class to manage player's health and game over logic
        class GameStatus:
            def __init__(self):
                self.health = 1000  # Player starts with 1000 health
                self.lives = 3 #player starts with 3 lives instead of 1

    def reduce_health(self):
        self.health -= 100  # Each collision reduces health by 100
        if self.health <= 0:  # If health drops to 0, game over
            self.lives -= 1   # Lose a life
            if self.lives > 0:
                self.health = 1000  # Reset health after losing a life
                print(f"Lives left: {self.lives}, Health reset to 1000")
                return True  # Indicate that the player should respawn
            else:
                self.game_over()  # If no lives left, game over
            return False  # Indicate that the player did not respawn

    def game_over(self):
        print('"Game over, sorry"')
        pygame.quit()  # Close the game window
        os._exit(1)  # Exit the program

game_status = GameStatus()  # Initialize the player's health status
clock = pygame.time.Clock()  # Initialize clock to control the frame rate

# Initialize platform objects (Rectangles) for player interaction
platforms = [
    pygame.Rect(100, 600, 100, 20),  # Platform 1 at x=100, y=400
    pygame.Rect(250, 400, 100, 20),  # Platform 2 at x=250, y=300
    pygame.Rect(400, 350, 100, 20)   # Platform 3 at x=400, y=200
]


# Main game loop where game logic runs
run = True
while run:
    clock.tick(30)  # Set frame rate to 30 frames per second

    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # Quit the game if player closes the window
            run = False

    # Handle player movement with keyboard input (WASD for movement)
    keys = pygame.key.get_pressed()

    # Move left (A key) and check left boundary
    if keys[pygame.K_a] and x > vel:
        x -= vel
    # Move right (D key) and check right boundary
    if keys[pygame.K_d] and x < 500 - width - vel:
        x += vel
    # Handle basic up/down movement if not jumping
    if not (isJump):
        if keys[pygame.K_w] and y > vel:  # Move up
            y -= vel
        if keys[pygame.K_s] and y < 500 - height - vel:  # Move down
            y += vel
        if keys[pygame.K_SPACE]:  # Start jumping if space is pressed
            isJump = True

    else:
        # Implement jump logic (smooth parabolic movement)
        if jumpCount >= -10:
            neg = 1
            if jumpCount < 0:
                neg = -1
            y -= (jumpCount ** 2) * 0.5 * neg
            jumpCount -= 1
        else:
            isJump = False
            jumpCount = 1

    # Gravity and jumping mechanics
    if not is_jumping:
        # Apply gravity if the player is not jumping
        if y < ground_y:
            y += fall_speed
            fall_speed += gravity
        else:
            y = ground_y  # Reset y-position to ground level
            fall_speed = 0  # Stop falling once player hits the ground

        # Start jumping when space is pressed
        if keys[pygame.K_SPACE]:
            is_jumping = True
            fall_speed = -jump_power  # Apply jump force

    else:
        # Jumping upward (negative fall_speed) or falling back down
        y += fall_speed
        fall_speed += gravity
        if fall_speed >= 0:  # Stop jumping when peak is reached
            is_jumping = False

    # Prevent player from falling off the screen (below ground)
    if y > ground_y:
        y = ground_y  # Keep player on the ground
        fall_speed = 0
        is_jumping = False

    # Platform collision detection (player lands on platforms)
    player_rect = pygame.Rect(x, y, width, height)
    for platform in platforms:
        if player_rect.colliderect(platform) and fall_speed >= 0:
            y = platform.y - height  # Place player on top of platform
            fall_speed = 0  # Stop falling when standing on a platform
            is_jumping = False

    # Enemy movement (enemy moves toward the player)
    if enemy_x < x:
        enemy_x += enemy_vel
    if enemy_x > x:
        enemy_x -= enemy_vel
    if enemy_y < y:
        enemy_y += enemy_vel
    if enemy_y > y:
        enemy_y -= enemy_vel

    # Fill the screen with black to refresh the frame
    win.fill((0, 0, 0))

    # Draw the player as a red rectangle
    player = pygame.draw.rect(win, (255, 0, 0), (x, y, width, height))

    # Draw the enemy as a blue rectangle
    enemy = pygame.draw.rect(win, (0, 0, 255), (enemy_x, enemy_y, enemy_width, enemy_height))

    # Draw the platforms as green rectangles
    for platform in platforms:
        pygame.draw.rect(win, (0, 255, 0), platform)

    # Check if player collides with enemy and reduce health
    if player.colliderect(enemy):
        game_status.reduce_health()
        print(f"Player health: {game_status.health}Lives: {game_status.lives}")

    # Implement basic attack mechanic (close-range attack with K key)
    attack_range = 50  # Define how close the player needs to be to attack
    attack_damage = 100  # Define the damage for a primary attack

    # If K key is pressed, check if enemy is in attack range
    if keys[pygame.K_k]:
        if abs(x - enemy_x) < attack_range and abs(y - enemy_y) < attack_range:
            enemy_health -= attack_damage  # Reduce enemy health on hit
            print(f"Enemy health: {enemy_health}")
            if enemy_health <= 0:  # If enemy health reaches 0, they are defeated
                print("Enemy defeated! +50 xp")
                enemy_x, enemy_y = -100, -100  # Move defeated enemy off-screen
                kills += 1  # Increment the kill counter

    # Implement secondary attack with L key (more damage, higher risk)
    if keys[pygame.K_l] and abs(x - enemy_x) < attack_range and abs(y - enemy_y) < attack_range:
        enemy_health -= attack_damage * 3  # Deal more damage with L key attack
        print(f"Enemy health: {enemy_health}")
        if enemy_health <= 0:
            print("Enemy defeated! +50 xp")
            enemy_x, enemy_y = -100, -100  # Move defeated enemy off-screen

    lives_text = font.render(f'Lives: {game_status.lives}', True, (255, 255, 255))
    win.blit(lives_text, (10, 100))  # Display lives below enemy health

    # Display player health and enemy health on the screen
    health_text = font.render(f'Health: {game_status.health}', True, (255, 255, 255))
    enemy_health_text = font.render(f'Enemy Health: {enemy_health}', True, (255, 255, 255))
    kills_text = font.render(f'Enemies Killed: {kills}', True, (255, 255, 255))
    lives_text = font.render(f'Lives: {game_status.lives}', True, (255, 255, 255))
    win.blit(health_text, (10, 10))
    win.blit(enemy_health_text, (10, 40))
    win.blit(kills_text, (10, 70))  # Display kills count below health
    win.blit(lives_text, (10, 100))  # Display lives below kills count


    pygame.display.update()

# Main menu function
def main_menu():
    running = True
    while running:
        win.fill((0, 0, 0))
        draw_button("Play", 200, 150, 100, 50, (200, 200, 200), (255, 255, 255))
        draw_button("Quit", 200, 250, 100, 50, (200, 200, 200), (255, 255, 255))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        pygame.display.update()

def draw_button(text, x, y, width, height, color, hover_color):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + width > mouse[0] > x and y + height > mouse[1] > y:
        pygame.draw.rect(win, hover_color, (x, y, width, height))
        if click[0] == 1:
            if text == "Quit":
                pygame.quit()
                sys.exit()
            elif text == "Play":
                game_loop()
    else:
        pygame.draw.rect(win, color, (x, y, width, height))

    text_surface = font.render(text, True, (0, 0, 0))
    win.blit(text_surface, (x + (width - text_surface.get_width()) // 2, y + (height - text_surface.get_height()) // 2))

# Start the game
main_menu()


