                                            #To do:
                                            #Create sprite
                                            #Add music (optional)
                                            #Add backround
                                            #add enemy sprite
                                            #Finsh with the comments and make sure that they are descriptive.
                                            #Then check on the rubric and make sure the program runs smoothly.


                                            # Program :
                                            # Author: Riley West
                                            # Date : 13/08/24
                                            # Version: 1.4

                                            # Importing pygame
                                            import pygame
                                            import os
                                            pygame.init()

                                            win = pygame.display.set_mode((500, 500))
                                            pygame.display.set_caption("First Game")

                                            # Setting up the font 
                                            font = pygame.font.SysFont(None, 55)

                                            # Date and time code
                                            import datetime
                                            current_time = datetime.datetime.now()
                                            print("Current time:", current_time)
                                            print("Year:", current_time.year)
                                            print("Month:", current_time.month)
                                            print("Day:", current_time.day)

                                            # Setting up the coordinates for basic python 
                                            x = 50
                                            y = 50
                                            width = 40
                                            height = 60
                                            vel = 5

                                            isJump = False
                                            jumpCount = 10
                                            run = True 

                                            # Load the background image and scale it
                                            background = pygame.image.load('toad.jpg')
                                            background = pygame.transform.scale(background, (500, 500))

                                            # Gravity and jump settings
                                            gravity = 1
                                            fall_speed = 0
                                            is_jumping = False
                                            jump_power = 20
                                            ground_y = 500 - height  # The level of the ground level

                                            # Enemy settings
                                            enemy_x = 400
                                            enemy_y = 400
                                            enemy_width = 40
                                            enemy_height = 60
                                            enemy_vel = 2
                                            enemy_health = 100  # Initialize enemy health

                                            # Health system
                                            class GameStatus:
                                                def __init__(self):
                                                    self.health = 1000

                                                def reduce_health(self):
                                                    self.health -= 100
                                                    if self.health <= 0:
                                                        self.game_over()

                                                def game_over(self):
                                                    print('"game over, sorry"')
                                                    pygame.quit()
                                                    os._exit(1)

                                            game_status = GameStatus()
                                            clock = pygame.time.Clock()

                                            # Initialize the platforms list with some pygame.Rect objects
                                            platforms = [
                                                pygame.Rect(100, 400, 100, 20),  # Platform 1
                                                pygame.Rect(250, 300, 100, 20),  # Platform 2
                                                pygame.Rect(400, 200, 100, 20)   # Platform 3
                                            ]

                                            win.blit(background, (0, 0))

                                            # Main game loop
                                            run = True
                                            while run:
                                                clock.tick(30)  # Set the frame rate to 30 frames per second

                                                for event in pygame.event.get():
                                                    if event.type == pygame.QUIT:
                                                        run = False

                                                # Setting up keys.
                                                keys = pygame.key.get_pressed()

                                                # Left and right movement with boundary checks
                                                if keys[pygame.K_a] and x > vel:
                                                    x -= vel
                                                if keys[pygame.K_d] and x < 500 - width - vel:
                                                    x += vel
                                                if not (isJump):
                                                    if keys[pygame.K_w] and y > vel:
                                                        y -= vel
                                                    if keys[pygame.K_s] and y < 500 - height - vel:
                                                        y += vel
                                                    if keys[pygame.K_SPACE]:
                                                        isJump = True

                                                else:
                                                    if jumpCount >= -10:
                                                        neg = 1
                                                        if jumpCount < 0:
                                                            neg = -1
                                                        y -= (jumpCount ** 2) * 0.5 * neg
                                                        jumpCount -= 1
                                                    else:
                                                        isJump = False
                                                        jumpCount = 1

                                                # Jumping and gravity mechanics
                                                if not is_jumping:
                                                    # Apply gravity if not jumping
                                                    if y < ground_y:
                                                        y += fall_speed
                                                        fall_speed += gravity
                                                    else:
                                                        y = ground_y
                                                        fall_speed = 0  # Reset fall speed when on the ground

                                                    # Initiate jump
                                                    if keys[pygame.K_SPACE]:
                                                        is_jumping = True
                                                        fall_speed = -jump_power  # Apply an upward force

                                                else:
                                                    # Continue jump until reaching the peak
                                                    y += fall_speed
                                                    fall_speed += gravity
                                                    if fall_speed >= 0:
                                                        is_jumping = False

                                                # Boundary check so that player doesn't fall off the screen
                                                if y > ground_y:
                                                    y = ground_y    
                                                    fall_speed = 0
                                                    is_jumping = False

                                                # Platform collision detection
                                                player_rect = pygame.Rect(x, y, width, height)
                                                for platform in platforms:
                                                    if player_rect.colliderect(platform) and fall_speed >= 0:
                                                        y = platform.y - height  # Place the player on top of the platform
                                                        fall_speed = 0  # Stop falling when landing on a platform
                                                        is_jumping = False

                                                # Enemy movement towards player (like a magnet)
                                                if enemy_x < x:
                                                    enemy_x += enemy_vel
                                                if enemy_x > x:
                                                    enemy_x -= enemy_vel
                                                if enemy_y < y:
                                                    enemy_y += enemy_vel
                                                if enemy_y > y:
                                                    enemy_y -= enemy_vel

                                                # This fills the whole screen with black
                                                win.fill((0, 0, 0))

                                                # Draw the player
                                                player = pygame.draw.rect(win, (255, 0, 0), (x, y, width, height))

                                                # Draw the enemy
                                                enemy = pygame.draw.rect(win, (0, 0, 255), (enemy_x, enemy_y, enemy_width, enemy_height))

                                                # Draw the platforms
                                                for platform in platforms:
                                                    pygame.draw.rect(win, (0, 255, 0), platform)  # Green platforms

                                                # How the enemy reacts to collision. This command "colliderect" checks for collision.
                                                if player.colliderect(enemy):
                                                    game_status.reduce_health()
                                                    print(f"Player health: {game_status.health}")

                                                # Making the fighting mechanics
                                                attack_range = 50
                                                attack_damage = 100

                                                # Checking attack range for primary attack (K key)
                                                if keys[pygame.K_k]:
                                                    if abs(x - enemy_x) < attack_range and abs(y - enemy_y) < attack_range:
                                                        enemy_health -= attack_damage
                                                        print(f"Enemy health: {enemy_health}")
                                                        if enemy_health <= 0:
                                                            print("Enemy defeated!, +50 xp")
                                                            enemy_x, enemy_y = -100, -100  # Move enemy off-screen when defeated

                                                # Checking attack range for secondary attack (L key)
                                                if keys[pygame.K_l] and abs(x - enemy_x) < attack_range and abs(y - enemy_y) < attack_range:
                                                    enemy_health -= attack_damage * 3  # Higher damage for secondary attack
                                                    print(f"Enemy health: {enemy_health}")
                                                    if enemy_health <= 0:
                                                        print("Enemy defeated!, +50 xp")
                                                        enemy_x, enemy_y = -100, -100  # Move enemy off-screen when defeated

                                                # Displaying the scoreboard
                                                health_text = font.render(f'Health: {game_status.health}', True, (255, 255, 255))
                                                enemy_health_text = font.render(f'Enemy Health: {enemy_health}', True, (255, 255, 255))
                                                win.blit(health_text, (10, 10))
                                                win.blit(enemy_health_text, (10, 40))

                                                # Update the display
                                                pygame.display.update()

                                            pygame.quit()



                                            #Extra platform code for later use when debugged.
                                            # platform=()
                                                #platforms=()
                                                #Platforms for 
                                                #class Platform(pygame.sprite.Sprite):
                                                #  def __init__(self, x, y, width, height):
                                                #     super().__init__()
                                                    #    self.image = pygame.Surface((width, height))
                                                    #   self.image.fill()
                                                    #  self.rect = self.image.get_rect()
                                                    # self.rect.x = x
                                                        #self.rect.y = y
                                                    #platform = platform(200, 400, 200, 20)  
                                                #platforms.add(platform)

                                                #all_sprites = pygame.sprite.Group()
                                                #all_sprites.add(player)
                                                #all_sprites.add(platform)
                                                #pygame.display.update()




                                            #e.g
                                            # Load character image
                                            #character_img = pygame.image.load('character.png')

                                            # Optionally scale the image (e.g., to match the character's original size)
                                            #character_img = pygame.transform.scale(character_img, (width, height))
