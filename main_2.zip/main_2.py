import pygame
pygame.init()

win = pygame.display.set_mode((500, 500))
pygame.display.set_caption("First Game")

# Setting up the coordinates
x = 50
y = 50
width = 40
height = 60
vel = 5

# Gravity and jump settings
gravity = 1
fall_speed = 0
is_jumping = False
jump_power = 15
ground_y = 500 - height  # The y-coordinate of the ground level

clock = pygame.time.Clock()

run = True
while run: 
    clock.tick(30)  # Set the frame rate to 30 frames per second

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Setting up keys.
    keys = pygame.key.get_pressed()

    # Left and right movement with boundary checks
    if keys[pygame.K_LEFT] and x > vel:
        x -= vel
    if keys[pygame.K_RIGHT] and x < 500 - width - vel:
        x += vel
    
    # Jumping and gravity mechanics
    if not is_jumping:
        # Apply gravity if not jumping
        if y < ground_y:
            y += fall_speed
            fall_speed += gravity
        else:
            y = ground_y
            fall_speed = 0  # Reset fall speed when on the ground

        # Initiate jump
        if keys[pygame.K_SPACE]:
            is_jumping = True
            fall_speed = -jump_power  # Apply an upward force
    
    else:
        # Continue jump until reaching the peak
        y += fall_speed
        fall_speed += gravity
        if fall_speed >= 0:
            is_jumping = False

    # Boundary check for y-axis to ensure the character doesn't fall through the ground
    if y > ground_y:
        y = ground_y
        fall_speed = 0
        is_jumping = False

    # This fills the whole screen like a paint bucket.
    win.fill((0, 0, 0))
    pygame.draw.rect(win, (255, 0, 0), (x, y, width, height))
    pygame.display.update()

pygame.quit()
