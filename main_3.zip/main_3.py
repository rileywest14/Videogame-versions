#Program :
#Author: Riley West
#Date : 13/08/24
#Version: 1.3


import pygame
pygame.init()
import os

win = pygame.display.set_mode((500, 500))
pygame.display.set_caption("First Game")

# circ = pygame.draw.circle(win, (0, 255, 0), (400, 300), 50)
circle_surf = pygame.Rect(400,400,80,80)

# Setting up the coordinates
x = 50
y = 50
width = 40
height = 60
vel = 5

isJump = False
jumpCount = 10

#Making a health bar 
class GameStatus:
    def __init__ (self):
        self.health = 100
    def reduce_health(self):
        self.health -= 10
        if self.health <= 0:
            pygame.quit

    def game_over():
        print (' "game over, sorry" ')
        os._exit(1)
        

# Gravity and jump settings
gravity = 1
fall_speed = 0
is_jumping = False
jump_power = 20
ground_y = 500 - height  # The y-coordinate of the ground level

clock = pygame.time.Clock()

run = True
while run: 
    clock.tick(30)  # Set the frame rate to 30 frames per second

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Setting up keys.
    keys = pygame.key.get_pressed()

    # Left and right movement with boundary checks
    if keys[pygame.K_LEFT] and x > vel:
        x -= vel
    if keys[pygame.K_RIGHT] and x < 500 - width - vel:
        x += vel
    if not (isJump):
        if keys[pygame.K_UP] and  y > vel:
            y-=vel
        if keys [pygame.K_DOWN] and y < 500 - height - vel:
            y+=vel
        if keys[pygame.K_SPACE]:
            isJump = True

    else:
        if jumpCount >= -10:
            neg = 1
            if jumpCount < 0:
                neg = -1
            y-= (jumpCount ** 2 ) * 0.5 * neg
            jumpCount -=1

        else:
            isJump = False  
            jumpCount = 1
    
    # Jumping and gravity mechanics
    if not is_jumping:
        # Apply gravity if not jumping
        if y < ground_y:
            y += fall_speed
            fall_speed += gravity
        else:
            y = ground_y
            fall_speed = 0  # Reset fall speed when on the ground

        # Initiate jump
        if keys[pygame.K_SPACE]:
            is_jumping = True
            fall_speed = -jump_power  # Apply an upward force
    
    else:
        # Continue jump until reaching the peak
        y += fall_speed
        fall_speed += gravity
        if fall_speed >= 0:
            is_jumping = False

    # Boundary check for y-axis to ensure the character doesn't fall through the ground
    if y > ground_y:
        y = ground_y
        fall_speed = 0
        is_jumping = False

    # This fills the whole screen like a paint bucket.
    win.fill((0, 0, 0))
    player = pygame.draw.rect(win, (255, 0, 0), (x, y, width, height))

    pygame.draw.circle(win, 'green', (400,400),80)

    if player.colliderect(circle_surf):
        print('hell naw')

    #hittable object
    pygame.display.update()

pygame.quit()



#To do 
#make objects like e.g a boulder 
#Make enemies spawn
#Change controls to wasd
#Make medium attack k 
#Make large attack l and make youi have to wait certain amount of time to acess large attack
